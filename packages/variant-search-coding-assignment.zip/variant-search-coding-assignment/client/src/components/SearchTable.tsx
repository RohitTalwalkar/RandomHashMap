/**
 * Compoent that lets users search for variants by their gene definition.
 */
import React, { Component } from 'react';

import 'antd/dist/antd.css';  // add AntD styles
import { AutoComplete, Table } from 'antd';
import { SelectValue } from 'antd/lib/select';

import './SearchTable.css';

export default class SearchTable extends Component {
    columns = [
        {
            title: 'Gene',
            dataIndex: 'gene',
            key: 'gene'
        },
        {
            title: 'Nucleotide Change',
            dataIndex: 'nucleotide_change',
            key: 'nucleotide_change'
        },
        {
            title: 'Protein Change',
            dataIndex: 'protein_change',
            key: 'protein_change'
        },
        {
            title: 'Alias',
            dataIndex: 'alias',
            key: 'alias'
        },
        {
            title: 'Region',
            dataIndex: 'region',
            key: 'region'
        },
        {
            title: 'Reported Classification',
            dataIndex: 'reported_classification',
            key: 'reported_classification'
        },
        {
            title: 'Last Evaluated',
            dataIndex: 'last_evaluated',
            key: 'last_evaluated'
        },
        {
            title: 'Last Updated',
            dataIndex: 'last_updated',
            key: 'last_updated'
        },
        {
            title: 'More Info',
            dataIndex: 'source',
            key: 'source',
            render: (text: string, record: any) => {
                return (
                    <a target='_blank' href={record.url}>{record.source}</a>
                );
            }
        }
    ];

    state = {
        currentPage: 1,
        data: [],
        geneSearch: null,
        geneSuggestions: [],
        isLoading: false,
        totalCount: 0,
    };

    processResults = (dataToConvert: Array<any>) => (
        dataToConvert.map((record: any, index: Number) => (
            {
                key: index,
                ...record,
            }
        ))
    )

    async loadDataForPage(pageNumber: Number) {
        this.setState({
            isLoading: true
        }, async () => {
            const url = this.state.geneSearch ?
                `http://localhost:8000/variants/?page=${this.state.currentPage}&geneSearch=${this.state.geneSearch}` :
                `http://localhost:8000/variants/?page=${this.state.currentPage}`;
            const response = await fetch(url);
            const data = await response.json();
            this.setState({
                totalCount: data.count,
                data: this.processResults(data.results),
                isLoading: false
            })
        });
    }

    async componentDidMount() {
        await this.loadDataForPage(this.state.currentPage);
    }

    handlePaginationChange = async (newPage: Number) => {
        this.setState({
            currentPage: newPage
        }, () => this.loadDataForPage(this.state.currentPage));
    }

    handleAutoCompleteSearch = async (searchText: String) => {
        const response = await fetch(`http://localhost:8000/genes/?geneSuggest=${searchText}`);
        const data = await response.json();
        if (data.results.length === 0) {
            this.setState({
                geneSuggestions: []
            })
        }
        this.setState({
            geneSuggestions: data
                .results.filter((result: any) => result.gene.length > 0)
                .map( (result: any) => result.gene)
        })

    }

    handleGeneSelect = (value: SelectValue) => {
        this.setState({
            geneSearch: value.toString()
        }, () => this.loadDataForPage(this.state.currentPage));
    }

    render() {
        return (
            <div>
                <div className='gene-search-container'>
                    Search by Gene: <AutoComplete
                        className='gene-search-input'
                        dataSource={this.state.geneSuggestions}
                        showSearch
                        onSearch={this.handleAutoCompleteSearch}
                        onSelect={this.handleGeneSelect}
                    />
                </div>
                <Table
                    loading={this.state.isLoading}
                    columns={this.columns}
                    dataSource={this.state.data}
                    pagination={{
                        pageSize: 15,
                        total: this.state.totalCount,
                        onChange: this.handlePaginationChange
                    }}
                />
            </div>
        );
    }
}

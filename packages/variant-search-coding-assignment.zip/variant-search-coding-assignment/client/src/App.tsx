import React, { Component } from 'react';
import './App.css';
import SearchTable from './components/SearchTable';

class App extends Component {
  state = {
    bordered: false,
    loading: false,
    title: undefined,
    rowSelection: {},
    scroll: undefined,
    hasData: true,
  }


  render() {
    return (
      <div className="App">
        <SearchTable />
      </div>
    );
  }
}

export default App;

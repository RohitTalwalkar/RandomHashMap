I bootstrapped my project using FaceBook's [Create React App](https://github.com/facebook/create-react-app).

That means you can view the client code in a browser via:
### `npm start`

And that should run the app and open a browser - or do that yourself:
[http://localhost:3000](http://localhost:3000)

I would have written tests even without being prompted.  You can run them with:
### `npm test`

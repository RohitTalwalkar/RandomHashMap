# Rohit Talwalkar's submisison:

## Libraries used and assumptions made:

IE11 support is not required.  If desired, a few polyfills should fix issues.
Users will have at least a 1280 x 1024 resolution for their monitors.
The number of 'genes' is ~10000 or less.

I bootstrapped the application using `create-react-app` and the `django-rest-framework`.
I used Ant Design for the UI (that's what we use at Nuna, its flexible, open-source, and extremely customizable), more info: http://ant.design/

## Run locally

### Prerequisites
The client requires `npm`, and the server requires `python` and `mysql` to be installed.

### Setup and run server

`cd` into the `server` folder, and create a new python environment (ex: `virtualenv env`, activate by `source env/bin/activate`), then run `pip install -r requirements.txt`.  Create a database user `django`, and set its password as an enviroment variable: `export DATABASE_PWD=<the django user password>`.  Then, setup the database by applying the migrations `python manage.py migrate`, then `python manage.py migrate --run-syncdb`.  Once the schema is setup, load data by starting a django shell: `python manage.py shell`, once in the shell run the import script (this will take several minutes): `import import_data.py`.  After the database is setup, start the server: `python manage.py runserver`.

### Setup and run client

In another terminal window, `cd` into the `client` folder and rum `npm install` (this will take a few minutes), then `npm start`.  That will start the client server and a browser will open, loading `http://localhost:3000/`.

## Questions asked & answers (thank you Matt and team!)

>I noticed 12144 rows don't have a value for "Gene".  That's about 25% of the data, so it feels like I
>probably parsed the file incorrectly.  Should I be using the previous value for "Gene" when its null
>for a given row?
You can skip the rows which do not have a "Gene" value.

>The screenshot seems to indicate that the column "Nucleotide Change" contains "nested data";
>with the other values coming from the "Other mappings" column.  Should I  include this
>expand/collapse behavior?  If so, is the additional data coming from the "Other mappings" column?
You should include the data, but the collapsing/expanding of that data is not required.  Yes, the addition data is coming from the "Other mappings" column.  To provide you with a little more context, the data in the "Nucleotide Change" column is the HGVS name for the variant on the primary transcript, and the comma-separated values in the "Other Mappings" column are the alternate names for the variant.  The expanding/collapsing feature as seen on the screenshot is just one way of presenting the alternate names for that variant, so you can display it fully expanded without the ability to collapse it, implement the collapsing feature, or consider other ways to display that data.

> Should we display a hyphen ("-") for empty/null values?
Sure.

>Is the "More Info" column displaying text from the "Source" column, with its hyperlink coming from
>the "URL" column?
Yes, that's correct.

>Quite a few columns (ex: "Transcripts", "Inferred Classification", "Submitter Comment") do not
>appear in the example screenshot.  Is that information valuable to show the user?  If so, could you
>share some potential use-cases, they'll help me think about how to best present the data.
The "Transcripts" column is not needed for display purposes since it's value is captured as part of the HGVS name of the variant.  The "Inferred Classification" is the normalized classification value that is derived from different submissions.  For example, one lab might submit a classification of "Uncertain significance" while other labs might use the value "Variant of uncertain significance" to mean the same thing.  The "Inferred Classification" column is an attempt to normalize on the same vocabulary so that they mean the same thing.  The "Inferred Classification" data might be useful to display for the variants where labs have disagreed on the classification of a variant, which is captured in the "Inferred Classification" column as well as a comma-separated value, but is not available in the "Reported Classification" column.  The "Submitter Comment" column contains info on what the submitter may have said to justify the value in the "Reported Classification" column for that variant.  It's useful data in case the user ever wants to find out more about why a variant was classified the way that it was.

There are other columns in the file such as the genomic location information (Genomic Start/Stop, Ref, Alt, Chr, etc) which are not required to be displayed as part of the exercise.  That info is useful for anyone wanting to display the presence of other variants upstream or downstream of that genomic location using something like a genome browser.  We don't expect you to implement a genome browser as part of this homework assignment, but should you happen to come across an genome browser or visualization library that you want to integrate with to display that information, then feel free to do so.  But is not required for the exercise.

# Original instructions

## Variant Search Coding Assignment

#### Assignment

Create a web application that allows a user to search for genomic variants by gene name and display the results in a tabular view.

#### Features

1. Allow the user to enter a gene name to search for variants in that gene. Display the results in a table that shows various attributes associated with each genomic variant.

2. Provide an auto-suggest feature for entering the gene name.

3. Provide two RESTful endpoints supporting the functionality listed in steps 1 and 2.

#### Datasource

A zipped TSV file of variants is available in /data/variants.tsv.zip. Each row in the TSV file represents a genomic variant and contains a Gene column with the gene name. A variant will belong to one and only one gene, but multiple variants may belong to the same gene.

#### Implementation

If you are comfortable with Python and/or React, please use these technologies for your app. You may use any additional frameworks, languages, databases, libraries, etc. that you find appropriate.

Our expectation is you will be writing some server code, client code, and applying some basic styling to create a working web application. The application should include unit tests.

Here’s an example of how you might group and display the information:

![variants table example](./example_table.png)

#### Submitting Your Solution

Please clone this repository and upload an archive to Greenhouse, or upload your repository to GitHub and send us a link. Update this README to include instructions on how to install, test, and run your application. Bonus: Deploy it and include the URL here.

As part of the review process, we may comment on or ask questions about specific parts of the code.

Please return your solution within 1 week. This is not an expectation of the time required to complete the assignment. Rather, it’s meant to provide buffer for busy schedules.

#### Questions

Please ask if any part of the assignment is unclear. Communicate with us as you would with your project team at work.

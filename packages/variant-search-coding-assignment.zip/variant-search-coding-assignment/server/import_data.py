# Python script used to import the tsv
import csv

# import the relevant model
from api_server.m import Variant

counter = 0
variant = list(csv.reader(open('../../data/variants.tsv', 'rt'), delimiter='\t'))

for line in variant:
     # add some custom validation\parsing for some of the fields
     print(line[0])
     print(line[1])
     print(line[2])
     counter = counter + 1
     if (counter > 10):
        exit()

    #  foo = Foo(fieldname1=line[1], fieldname2=line[2] ... etc. )
    #  try:
    #      foo.save()
    #  except:
    #      # if the're a problem anywhere, you wanna know about it
    #      print "there was a problem with line", i 
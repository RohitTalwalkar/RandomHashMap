from django.apps import AppConfig


class InvitaeConfig(AppConfig):
    name = 'invitae'
